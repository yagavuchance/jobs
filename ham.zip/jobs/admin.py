from django.contrib import admin
from .models import Jobs

# Register your models here.

admin.site.register(Jobs)
