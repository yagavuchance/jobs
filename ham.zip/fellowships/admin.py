from django.contrib import admin
from .models import Fellowship

# Register your models here.
admin.site.register(Fellowship)
