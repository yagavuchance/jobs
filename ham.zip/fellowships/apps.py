from django.apps import AppConfig


class FellowshipsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'fellowships'
